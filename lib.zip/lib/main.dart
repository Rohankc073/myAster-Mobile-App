import 'package:flutter/material.dart';
import 'package:myasteer/app.dart';

void main() {
  runApp(const MyApp());
}

import 'package:equatable/equatable.dart';
// part of 'register_bloc.dart';

sealed class SignupEvent extends Equatable {
  const SignupEvent();

  @override
  List<Object> get props => [];
}

class LoadCoursesAndBatches extends SignupEvent {}

class RegisterStudent extends SignupEvent {}

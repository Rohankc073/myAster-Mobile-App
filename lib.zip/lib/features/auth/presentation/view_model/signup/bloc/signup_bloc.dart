import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:myasteer/features/auth/presentation/view_model/signup/bloc/signup_event.dart';
import 'package:myasteer/features/auth/presentation/view_model/signup/bloc/signup_state.dart';

part 'register_event.dart';
part 'register_state.dart';

class SignupBloc extends Bloc<SignupEvent, SignupState> {
  final BatchBloc _batchBloc;
  final CourseBloc _courseBloc;

  SignupBloc({
    required BatchBloc batchBloc,
    required CourseBloc courseBloc,
  })  : _batchBloc = batchBloc,
        _courseBloc = courseBloc,
        super(SignupState.initial()) {
    on<LoadCoursesAndBatches>(_onRegisterEvent);

    add(LoadCoursesAndBatches());
  }

  void _onRegisterEvent(
    LoadCoursesAndBatches event,
    Emitter<SignupState> emit,
  ) {
    emit(state.copyWith(isLoading: true));
    _batchBloc.add(LoadBatches());
    _courseBloc.add(CourseLoad());
    emit(state.copyWith(isLoading: false, isSuccess: true));
  }
}
